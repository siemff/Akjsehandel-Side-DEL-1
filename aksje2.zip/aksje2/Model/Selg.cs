﻿using System;
namespace aksje2.Model
{
    public class Selg
    {
        public int personId { get; set; }
        public int aksjeId { get; set; }
        public int antall { get; set; }
    }
}

