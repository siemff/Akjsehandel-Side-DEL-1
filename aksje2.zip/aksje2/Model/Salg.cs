﻿using System;
namespace aksje2.Model
{
    public class Salg
    {
        public int person { get; set; }
        public int antall { get; set; }
        public decimal pris { get; set; }
        public int aksje { get; set; }
    }
}

